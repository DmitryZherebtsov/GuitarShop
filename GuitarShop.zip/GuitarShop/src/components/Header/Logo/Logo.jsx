import React from 'react'

const Logo = () => {
  return (
    <div>
        Logo
    </div>
  )
}

export default Logo