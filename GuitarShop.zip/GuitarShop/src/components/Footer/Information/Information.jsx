import React from 'react'
import './Information.css'

const Information = () => {
  return (
    <div>
      
      
      <div>
        <h2>Information</h2>
       </div>

       <div className='information'>
          <a href="">Find Artists</a>
          <a href="">Guitars     </a>
          <a href="">Cart        </a>
          <a href="">About Us    </a>
       </div>

    </div>
  )
}

export default Information
